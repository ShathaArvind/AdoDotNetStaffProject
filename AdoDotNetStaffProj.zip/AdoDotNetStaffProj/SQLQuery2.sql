﻿ALTER TABLE Staff
DROP COLUMN CID;

ALTER TABLE Staff
ADD CID int;

select * from Staff;