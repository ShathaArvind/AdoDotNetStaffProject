﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AdoDotNetStaffProj.models;

namespace AdoDotNetStaffProj
{
    public partial class Details : Form
    {
        public Details()
        {
            InitializeComponent();
        }

        private void Details_Load(object sender, EventArgs e)
        {
            StaffLogic ob = new StaffLogic();
            dataGridView1.DataSource = ob.getStaffDetails();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 ob = new Form1();
            ob.Show();
        }

        private void iNSERTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InsertData ob = new InsertData();
            ob.Show();
            this.Hide();
        }

        private void uPDATEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateData ob = new UpdateData();
            ob.Show();
            this.Hide();
        }

        private void dELETEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteData ob = new DeleteData();
            ob.Show();
            this.Hide();
        }

        private void dETAILSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Details ob = new Details();
            ob.Show();
            this.Hide();
        }

        private void sEARCHToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SearchData ob = new SearchData();
            ob.Show();
            this.Hide();
        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("THANK YOU FOR VISITING");
            Application.Exit();
        }

        private void dBDETAILSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DB_Details ob = new DB_Details();
            ob.Show();
            this.Hide();
        }
    }
}
