﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AdoDotNetStaffProj.models
{
    class StaffLogic
    {
        private string connStr = ConfigurationManager.ConnectionStrings["staffdb"].ConnectionString;
        public List<Staff> getStaffDetails()
        {
            List<Staff> li = new List<Staff>();
            SqlConnection conn = new SqlConnection(connStr);

            try
            {
                conn.Open();
                string sql = "select * from Staff";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Staff s = new Staff();
                    s.Id = Convert.ToInt32(reader.GetValue(0));
                    s.StaffName = reader.GetValue(1).ToString();
                    s.Experiance = Convert.ToInt32(reader.GetValue(2));
                    s.CID = Convert.ToInt32(reader.GetValue(3));
                    li.Add(s);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }

            return li;
        }
        public string AddData(Staff staff)
        {
            string message = "";
            // string sql =" insert into Student(STUDENTNAME, EMAIL, PHONE, FEES,\"PERCENT\")values('";
            //   sql += student.Name + "','" + student.Email + "','" + student.Phone + "','" + student.Fees + "','" + student.Percent + ")";


            string sql = String.Format("insert into Staff(STAFFNAME, EXPERIANCE,CID) values('{0}','{1}','{2}')",
                staff.StaffName, staff.Experiance, staff.CID);

            SqlConnection conn = new SqlConnection(connStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteReader();
                message = " The record inserted sucessfully..." + staff.ToString();
            }
            catch (Exception e)
            {
                message = e.Message;
            }
            finally
            {
                conn.Close();
            }

            return message;
        }
        public DataSet GetSearchData(int id)
        {
            DataSet ds = new DataSet();
            SqlConnection conn = new SqlConnection(connStr);
            string sql = "select * from Staff where Id =" + id.ToString();

            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                da.Fill(ds);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }

        public string Updatedata(Staff s)
        {
            string message = "";
            SqlConnection conn = new SqlConnection(connStr);

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("sproc_update", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@id", SqlDbType.Int).Value = s.Id;
                cmd.Parameters.Add("@name", SqlDbType.VarChar, 50).Value = s.StaffName;
                cmd.Parameters.Add("@experiance", SqlDbType.VarChar, 50).Value = s.Experiance;
                cmd.Parameters.Add("@cid", SqlDbType.VarChar, 10).Value = s.CID;

                cmd.ExecuteNonQuery();
                message = "Data Updated Sucessfully";
            }
            catch (Exception e)
            {
                message = e.Message;
            }
            finally
            {
                conn.Close();
            }

            return message;
        }
        public string DeleteData(int id)
        {
            string message = "";
            SqlConnection conn = new SqlConnection(connStr);

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SPROC_DELSTAFF", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = id;
                cmd.ExecuteNonQuery();
                message = "Deleted Sucessfully!!";

            }
            catch (Exception e)
            {
                message = e.Message;
            }
            finally
            {
                conn.Close();
            }

            return message;
        }
        public DataSet gettabledata()
        {
            DataSet ds = new DataSet();
            SqlConnection conn = new SqlConnection(connStr);
            string sql = "select * from sys.tables;select * from Staff";

            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                da.Fill(ds);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }
    }
}
