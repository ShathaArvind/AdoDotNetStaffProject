﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoDotNetStaffProj.models
{
    class Staff
    {
        public int Id { get; set; }
        public string StaffName { get; set; }
        public int Experiance { get; set; }
        public int CID { get; set; }

        public override string ToString()
        {
            string str = "";
            str += " STAFF NAME : " + StaffName;
            str += " EXPERIANCE : " + Experiance;
            str += " CID : " + CID;
            return str;
        }

    }
}
