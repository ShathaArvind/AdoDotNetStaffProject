﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AdoDotNetStaffProj.models;

namespace AdoDotNetStaffProj
{
    public partial class UpdateData : Form
    {
        StaffLogic ob = new StaffLogic();
        public UpdateData()
        {
            InitializeComponent();
        }

        private void UpdateData_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            panel1.Visible = false;
            subbtn.Visible = false;
        }

        private void bckbtn_Click(object sender, EventArgs e)
        {
            Form1 ob1 = new Form1();
            ob1.Show();
            this.Hide();
        }

        private void srchbtn_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtid.Value.ToString());
            DataSet res = ob.GetSearchData(id);
            if (Convert.ToInt32(res.Tables[0].Rows.Count.ToString()) > 0)
            {
                panel1.Visible = true;
                txtname.Text = res.Tables[0].Rows[0]["StaffName"].ToString();
                txtexp.Text = res.Tables[0].Rows[0]["Experiance"].ToString();
                txtcid.Text = res.Tables[0].Rows[0]["CID"].ToString();
                subbtn.Visible = true;
            }
            else
            {
                MessageBox.Show("Record With id dose not exists!!");
            }
        }

        private void subbtn_Click(object sender, EventArgs e)
        {
            Staff s = new Staff();

            s.Id = Convert.ToInt32(txtid.Value);
            s.StaffName = txtname.Text;
            s.Experiance = int.Parse(txtexp.Text);
            s.CID = int.Parse(txtcid.Text);

            string msg = ob.Updatedata(s);
            MessageBox.Show(msg);
            dataGridView1.DataSource = ob.getStaffDetails();
            dataGridView1.Visible = true;
        }

        private void iNSERTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InsertData ob = new InsertData();
            ob.Show();
            this.Hide();
        }

        private void uPDATEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateData ob = new UpdateData();
            ob.Show();
            this.Hide();
        }

        private void dELETEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteData ob = new DeleteData();
            ob.Show();
            this.Hide();
        }

        private void dETAILSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Details ob = new Details();
            ob.Show();
            this.Hide();
        }

        private void sEARCHToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SearchData ob = new SearchData();
            ob.Show();
            this.Hide();
        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("THANK YOU FOR VISITING");
            Application.Exit();
        }

        private void dBDETAILSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DB_Details ob = new DB_Details();
            ob.Show();
            this.Hide();
        }
    }
}
