﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AdoDotNetStaffProj.models;

namespace AdoDotNetStaffProj
{
    public partial class DeleteData : Form
    {
        StaffLogic ob = new StaffLogic();
        public DeleteData()
        {
            InitializeComponent();
        }

        private void delbtn_Click(object sender, EventArgs e)
        {

            int id = Convert.ToInt32(txtid.Value.ToString());
            DataSet res = ob.GetSearchData(id);
            if (Convert.ToInt32(res.Tables[0].Rows.Count.ToString()) > 0)
            {
                string msg = ob.DeleteData(id);
                MessageBox.Show(msg);
            }
            else
            {
                MessageBox.Show("ID DOES NOT EXISTS!!");
            }

        }

        private void bckbtn_Click(object sender, EventArgs e)
        {
            Form1 ob1 = new Form1();
            ob1.Show();
            this.Hide();
        }

        private void iNSERTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InsertData ob = new InsertData();
            ob.Show();
            this.Hide();
        }

        private void uPDATEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateData ob = new UpdateData();
            ob.Show();
            this.Hide();
        }

        private void dELETEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteData ob = new DeleteData();
            ob.Show();
            this.Hide();
        }

        private void dETAILSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Details ob = new Details();
            ob.Show();
            this.Hide();
        }

        private void sEARCHToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SearchData ob = new SearchData();
            ob.Show();
            this.Hide();
        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("THANK YOU FOR VISITING");
            Application.Exit();
        }

        private void dBDETAILSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DB_Details ob = new DB_Details();
            ob.Show();
            this.Hide();
        }
    }
}
