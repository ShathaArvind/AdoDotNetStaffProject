﻿namespace AdoDotNetStaffProj
{
    partial class InsertData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InsertData));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtexp = new System.Windows.Forms.TextBox();
            this.txtcid = new System.Windows.Forms.TextBox();
            this.subbtn = new System.Windows.Forms.Button();
            this.bckbtn = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mODIFYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iNSERTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uPDATEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dELETEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rETRIVEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dETAILSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sEARCHToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dBDETAILSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aPPLICATIONToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eXITToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Aqua;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(27, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "STAFF NAME";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Aqua;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(27, 140);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 27);
            this.label2.TabIndex = 1;
            this.label2.Text = "EXPERIENCE";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Aqua;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(60, 213);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 27);
            this.label3.TabIndex = 2;
            this.label3.Text = "CID";
            // 
            // txtname
            // 
            this.txtname.BackColor = System.Drawing.Color.Aqua;
            this.txtname.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(197, 67);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(121, 34);
            this.txtname.TabIndex = 4;
            // 
            // txtexp
            // 
            this.txtexp.BackColor = System.Drawing.Color.Aqua;
            this.txtexp.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtexp.Location = new System.Drawing.Point(197, 137);
            this.txtexp.Name = "txtexp";
            this.txtexp.Size = new System.Drawing.Size(121, 34);
            this.txtexp.TabIndex = 5;
            // 
            // txtcid
            // 
            this.txtcid.BackColor = System.Drawing.Color.Aqua;
            this.txtcid.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcid.Location = new System.Drawing.Point(197, 210);
            this.txtcid.Name = "txtcid";
            this.txtcid.Size = new System.Drawing.Size(121, 34);
            this.txtcid.TabIndex = 6;
            // 
            // subbtn
            // 
            this.subbtn.BackColor = System.Drawing.Color.Aqua;
            this.subbtn.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.subbtn.Location = new System.Drawing.Point(100, 338);
            this.subbtn.Name = "subbtn";
            this.subbtn.Size = new System.Drawing.Size(108, 43);
            this.subbtn.TabIndex = 8;
            this.subbtn.Text = "INSERT";
            this.subbtn.UseVisualStyleBackColor = false;
            this.subbtn.Click += new System.EventHandler(this.subbtn_Click);
            // 
            // bckbtn
            // 
            this.bckbtn.BackColor = System.Drawing.Color.Aqua;
            this.bckbtn.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bckbtn.Location = new System.Drawing.Point(281, 338);
            this.bckbtn.Name = "bckbtn";
            this.bckbtn.Size = new System.Drawing.Size(102, 43);
            this.bckbtn.TabIndex = 9;
            this.bckbtn.Text = "BACK";
            this.bckbtn.UseVisualStyleBackColor = false;
            this.bckbtn.Click += new System.EventHandler(this.bckbtn_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Aqua;
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(474, 83);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(151, 27);
            this.label5.TabIndex = 10;
            this.label5.Text = "INSERT DATA";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mODIFYToolStripMenuItem,
            this.rETRIVEToolStripMenuItem,
            this.aPPLICATIONToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 14;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mODIFYToolStripMenuItem
            // 
            this.mODIFYToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.iNSERTToolStripMenuItem,
            this.uPDATEToolStripMenuItem,
            this.dELETEToolStripMenuItem});
            this.mODIFYToolStripMenuItem.Name = "mODIFYToolStripMenuItem";
            this.mODIFYToolStripMenuItem.Size = new System.Drawing.Size(75, 24);
            this.mODIFYToolStripMenuItem.Text = "MODIFY";
            // 
            // iNSERTToolStripMenuItem
            // 
            this.iNSERTToolStripMenuItem.Name = "iNSERTToolStripMenuItem";
            this.iNSERTToolStripMenuItem.Size = new System.Drawing.Size(138, 26);
            this.iNSERTToolStripMenuItem.Text = "INSERT";
            this.iNSERTToolStripMenuItem.Click += new System.EventHandler(this.iNSERTToolStripMenuItem_Click_1);
            // 
            // uPDATEToolStripMenuItem
            // 
            this.uPDATEToolStripMenuItem.Name = "uPDATEToolStripMenuItem";
            this.uPDATEToolStripMenuItem.Size = new System.Drawing.Size(138, 26);
            this.uPDATEToolStripMenuItem.Text = "UPDATE";
            this.uPDATEToolStripMenuItem.Click += new System.EventHandler(this.uPDATEToolStripMenuItem_Click_1);
            // 
            // dELETEToolStripMenuItem
            // 
            this.dELETEToolStripMenuItem.Name = "dELETEToolStripMenuItem";
            this.dELETEToolStripMenuItem.Size = new System.Drawing.Size(138, 26);
            this.dELETEToolStripMenuItem.Text = "DELETE";
            this.dELETEToolStripMenuItem.Click += new System.EventHandler(this.dELETEToolStripMenuItem_Click_1);
            // 
            // rETRIVEToolStripMenuItem
            // 
            this.rETRIVEToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dETAILSToolStripMenuItem,
            this.sEARCHToolStripMenuItem,
            this.dBDETAILSToolStripMenuItem});
            this.rETRIVEToolStripMenuItem.Name = "rETRIVEToolStripMenuItem";
            this.rETRIVEToolStripMenuItem.Size = new System.Drawing.Size(76, 24);
            this.rETRIVEToolStripMenuItem.Text = "RETRIVE";
            // 
            // dETAILSToolStripMenuItem
            // 
            this.dETAILSToolStripMenuItem.Name = "dETAILSToolStripMenuItem";
            this.dETAILSToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.dETAILSToolStripMenuItem.Text = "DETAILS";
            this.dETAILSToolStripMenuItem.Click += new System.EventHandler(this.dETAILSToolStripMenuItem_Click_1);
            // 
            // sEARCHToolStripMenuItem
            // 
            this.sEARCHToolStripMenuItem.Name = "sEARCHToolStripMenuItem";
            this.sEARCHToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.sEARCHToolStripMenuItem.Text = "SEARCH";
            this.sEARCHToolStripMenuItem.Click += new System.EventHandler(this.sEARCHToolStripMenuItem_Click_1);
            // 
            // dBDETAILSToolStripMenuItem
            // 
            this.dBDETAILSToolStripMenuItem.Name = "dBDETAILSToolStripMenuItem";
            this.dBDETAILSToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.dBDETAILSToolStripMenuItem.Text = "DB_DETAILS";
            this.dBDETAILSToolStripMenuItem.Click += new System.EventHandler(this.dBDETAILSToolStripMenuItem_Click);
            // 
            // aPPLICATIONToolStripMenuItem
            // 
            this.aPPLICATIONToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eXITToolStripMenuItem});
            this.aPPLICATIONToolStripMenuItem.Name = "aPPLICATIONToolStripMenuItem";
            this.aPPLICATIONToolStripMenuItem.Size = new System.Drawing.Size(110, 24);
            this.aPPLICATIONToolStripMenuItem.Text = "APPLICATION";
            // 
            // eXITToolStripMenuItem
            // 
            this.eXITToolStripMenuItem.Name = "eXITToolStripMenuItem";
            this.eXITToolStripMenuItem.Size = new System.Drawing.Size(113, 26);
            this.eXITToolStripMenuItem.Text = "EXIT";
            this.eXITToolStripMenuItem.Click += new System.EventHandler(this.eXITToolStripMenuItem_Click_1);
            // 
            // InsertData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.bckbtn);
            this.Controls.Add(this.subbtn);
            this.Controls.Add(this.txtcid);
            this.Controls.Add(this.txtexp);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "InsertData";
            this.Text = "InsertData";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtexp;
        private System.Windows.Forms.TextBox txtcid;
        private System.Windows.Forms.Button subbtn;
        private System.Windows.Forms.Button bckbtn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mODIFYToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iNSERTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uPDATEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dELETEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rETRIVEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dETAILSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sEARCHToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aPPLICATIONToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eXITToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dBDETAILSToolStripMenuItem;
    }
}