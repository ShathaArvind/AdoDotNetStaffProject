﻿create procedure sproc_update1
(    @id int,
     @name varchar(50),
	 @experiance int,
	 @cid int

)
as
begin
      update Staff
	  set StaffName=@name,Experiance=@experiance,CID=@cid
	  where Id=@id;
	  end

select * from Staff where Id=101;

exec sproc_update1 101, 'Sai', 10,20
